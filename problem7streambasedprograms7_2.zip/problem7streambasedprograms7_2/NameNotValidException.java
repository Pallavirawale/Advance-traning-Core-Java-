package problem7streambasedprograms7_2;


public class NameNotValidException extends Exception
{
    public String validname()
    {
         return ("Name is not Valid..Please ReEnter the Name");
    }
}