package problem1;
import java.util.Scanner;

public class EvenNo {
public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the value:");
		int n=sc.nextInt();
		
		for(int i=1;i<=n;i++) {
			
			if(i%2==0) {
				System.out.println("Even numbers are  : " +" "+i);
				
			}
		}
	}
}